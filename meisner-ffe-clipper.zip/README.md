# Meisner FFE Clipper - Chrome Extension

A Chrome extension that lets you clip product information from any website and save it directly to your StudioFlow FFE schedules.

## Environments

- **Local Development**: `http://localhost:3000`
- **Production**: `https://app.meisnerinteriors.com`

To switch environments, edit `ENVIRONMENT` at the top of both `popup.js` and `background.js`:
```javascript
const ENVIRONMENT = 'local';  // Change to 'production' for live
```

## Features

- **Smart Fill**: Automatically extracts product information from web pages
- **Manual Selection**: Click the + button and hover over text to select specific fields
- **Image Clipping**: Right-click on images to clip them to your project
- **Project Integration**: Select Project → Room → Section to save items

## Installation

1. Open Chrome and navigate to `chrome://extensions/`
2. Enable **Developer mode** (top right toggle)
3. Click **Load unpacked**
4. Select the `chrome-extension` folder

## First-Time Setup

1. After installing, click the extension icon in Chrome toolbar
2. Click "Log In" - this opens the authentication page
3. Sign in to StudioFlow if not already signed in
4. Click "Generate API Key"
5. The extension will automatically connect

## Usage

### Smart Fill
1. Navigate to a product page on any website
2. Click the Meisner extension icon
3. Click "Smart fill from current page"
4. Review and edit the extracted information
5. Click "Clip" to select a location
6. Choose Project → Room → Section
7. Click "Save Item"

### Manual Selection
1. Click the + icon next to any field
2. Hover over text on the webpage
3. Click to capture the text
4. Press ESC to cancel

### Image Clipping
1. Right-click on any image
2. Select "Clip Image to StudioFlow"
3. The image will be added to your current clip

## Supported Fields

- Product Name & Description
- Brand
- Product Website (auto-filled)
- Doc Code & SKU
- Colour, Finish, Material
- Dimensions (Width, Length, Height, Depth)
- Quantity
- RRP & Trade Price
- Lead Time
- Notes
- Images & Attachments

## Adding Custom Icons (Optional)

To add your logo to the extension:

1. Create an `icons` folder in `chrome-extension/`
2. Add PNG files named:
   - `icon16.png` (16x16 pixels)
   - `icon32.png` (32x32 pixels)
   - `icon48.png` (48x48 pixels)
   - `icon128.png` (128x128 pixels)
3. Update `manifest.json` to include:
```json
"action": {
  "default_icon": {
    "16": "icons/icon16.png",
    "32": "icons/icon32.png",
    "48": "icons/icon48.png",
    "128": "icons/icon128.png"
  }
},
"icons": {
  "16": "icons/icon16.png",
  "32": "icons/icon32.png",
  "48": "icons/icon48.png",
  "128": "icons/icon128.png"
}
```

## File Structure

```
chrome-extension/
├── manifest.json       # Extension configuration
├── popup.html          # Main popup UI
├── popup.js            # Popup logic
├── styles.css          # Popup styles
├── content.js          # Page content script
├── content-styles.css  # Content script styles
├── background.js       # Service worker
└── README.md           # This file
```

## Troubleshooting

### "Unauthorized" error
- Go to `http://localhost:3000/extension-auth` (or production URL)
- Generate a new API key
- Refresh the extension

### Extension not loading
- Check that Developer mode is enabled
- Try clicking "Update" on the extensions page
- Check the console for errors (right-click extension icon → Inspect popup)

## License

Proprietary - Meisner Interiors
